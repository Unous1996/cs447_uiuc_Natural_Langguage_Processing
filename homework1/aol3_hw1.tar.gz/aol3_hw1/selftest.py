from collections import defaultdict

dict = defaultdict(list)
dict[1].append(2)
dict[2].append(3)
